How to run the Vehicle Parking Management System Project
1. Extract the zip file
2. Copy the vpms folder
3. Paste inside root directory(for xampp xampp/htdocs)
4. Open PHPMyAdmin (http://localhost/phpmyadmin)
5. Create a database with name vpmsdb
6. Import vpmsdb.sql file(given inside the vpms folder)
7. Run the script http://localhost/vpms (frontend)
Username: admin
Password: admin